from .bus_data_loader import Data
from sklearn.model_selection import train_test_split
import os


def get_data():
    path1 = "automotive_featureengineering/utils/test_data_vehicle/Gesammelt_red_red"
    path2 = "../../../../mnt/Trainingsdaten/223-1859/Gesammelt_red/"
    data_loader = Data(
        path1,
        "I_",
        fuse_bus_file="automotive_featureengineering/utils/test_data_vehicle/Fuses_List_Original.txt",
    )

    target_info = data_loader.get_fuses()
    print("Target Info", target_info[0])
    imported_data = data_loader.import_data("F206", 0.2, target_info[0])

    # Print the imported data
    print(f"Imported data shape: {imported_data.shape}")
    print("Creating 80:20 train test split.")
    train_df, test_df = train_test_split(imported_data, test_size=0.2, random_state=42)
    print(f"Train shape: {train_df.shape}")
    print(f"Test shape: {test_df.shape}")

    return train_df, test_df
