#!/usr/bin/env python
# coding: utf-8

# # EnergAIze: AI@Energieeffizienz
#
# Classes to import bus and measurement data

import os, glob, time, logging, re
import pandas as pd
import numpy as np
from asammdf import MDF
from pathlib import Path
import datetime

##########################################
# Create logger and logfile
##########################################
time_string = datetime.datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
Path("./Logs").mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    filename=os.path.join("./Logs", time_string + ".log"),
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(message)s",
    datefmt="%H:%M:%S",
    filemode="w",
)
logger = logging.getLogger()
logger.addHandler(logging.StreamHandler())


class Data:
    """
    A class to import bus data in mf4 format.

    ...

    Attributes
    ----------
    filedir : str
        path of directory with all mf4 files
    fuse_bus_file : str
        path to file containing the fuse-bus assignment
    signaldir : str
        path of directory with textfiles for each fuse containing the signalnames of signals to be used
    blacklist : str
        path to file containing a textfile of signals not to be used
    fuse_prefix : str
        fuse prefix used in the mf4 files

    Methods
    -------
    get_fuses() -> dict:
        returns dictionary of all fuses with their corresponding busses

    import_data(self,
        fuse: str,
        raster: float,
        fi_signalnumber: Optional[int],
        fi_signalthreshold: Optional[float],
        fuse_bus_dict_model: Optional[dict],
        feature_list_model: Optional[list],
        target_list_model: Optional[list],
        use_outer_join: Optional[bool]) -> pd.DataFrame:
        returns pandas data frame containing all bus data from mf4 files
    """

    def __init__(
        self,
        filedir,
        fuse_prefix,
        fuse_bus_file=None,
        signaldir=None,
        blacklist=None,
        modellib=None,
        target_signal=None,
    ):
        self.filedir = filedir
        print(self.filedir)
        self.fuse_bus_file = fuse_bus_file
        print(self.fuse_bus_file)
        self.signaldir = signaldir
        self.blacklist = blacklist
        self.fuse_bus_dict = {}
        self.dict_files = {}
        self.set_fuses_names = set()
        self.fuse_prefix = fuse_prefix
        self.modellib = modellib
        self.target_signal = target_signal

        if not filedir:
            logger.error("No filedir specified!")
            raise ValueError("No filedir specified!")

    ##########################################
    # Method to get all fuses listed in fuses.txt and import all mf4 files from filedir
    ##########################################
    def get_fuses(self):
        """Method to get all fuses listed in fuses.txt and import all mf4 files from filedir"""
        self.__organize_files()
        self.__generate_fuse_set()
        return self.fuse_bus_dict, self.set_fuses_names

    ##########################################
    # Method to import raw data from mf4-files in dataframes
    ##########################################
    def import_data(
        self,
        fuse,
        raster,
        fi_signalnumber=None,
        fi_signalthreshold=None,
        fuse_bus_dict_model=None,
        feature_list_model=None,
        target_list_model=None,
        use_outer_join: bool = False,
        feature_engineering=None,
        disable_bus_check: bool = False,
        filter_living_state: bool = False,
    ) -> pd.DataFrame | None:
        """Creates pandas data frame containing all bus data from mf4 files"""
        start_time = time.time()

        dict_signallist = self.__create_signallist(
            fuse, fi_signalnumber, fi_signalthreshold
        )
        list_blacklist = self.__create_blacklist()

        # Use signals from imported joblib file if availible
        if fuse_bus_dict_model:
            df = self.__load_files(
                fuse,
                raster,
                dict_signallist,
                list_blacklist,
                fuse_bus_dict_model,
                feature_list_model,
                target_list_model,
                use_outer_join,
                feature_engineering,
                disable_bus_check,
                filter_living_state,
            )
        else:
            df = self.__load_files(
                fuse,
                raster,
                dict_signallist,
                list_blacklist,
                self.fuse_bus_dict,
                feature_list_model,
                target_list_model,
                use_outer_join,
                feature_engineering,
                disable_bus_check,
                filter_living_state,
            )

        logger.info(
            f"--- {time.time() - start_time} seconds to import files for fuse {fuse}---"
        )
        return df

    ##########################################
    # Zuordnung aller Sicherungen und Busse sowie zeitliche Gruppierung der mf4-Dateien
    ##########################################
    def __organize_files(self):
        """Zuordnung aller Sicherungen und Busse sowie zeitliche Gruppierung der mf4-Dateien"""
        if not self.modellib:
            self.__generate_fuse_bus_allocation()

        self.__generate_mf4_file_dict()

    ##########################################
    # Import textfiles with fuse-bus allocation
    ##########################################
    def __generate_fuse_bus_allocation(self):
        if not self.fuse_bus_file or not os.path.isfile(self.fuse_bus_file):
            logger.warn("No fuse_bus_file was found!")
            raise ValueError("No fuse_bus_file was found!")

        with open(self.fuse_bus_file, "r") as filestream:
            # Einlesen aller Sicherungen mit den dazugehoerigen Bussen aus der Textdatei
            for line in filestream:
                if line.startswith("#"):
                    continue
                # Remove all leading/trailing whitespaces, tabs etc.
                line = line.strip().strip()
                regex = re.compile(r"[F|A]\S{1,}[:][^\r\n\t\f\v# ]{4,}")
                match = regex.findall(line)
                if len(match) > 0:
                    currentline = match[0].split(":")
                    self.fuse_bus_dict[currentline[0]] = currentline[1].split(",")
                else:
                    logger.info(f"Ignoring line '{line}'")

    ##########################################
    # Generate dict with all mf4 files in filedir and sort them by timeframe
    ##########################################
    def __generate_mf4_file_dict(self):
        # Wenn mehrere Dateipfade zu Ordnern in filedir übergeben werden, werden diese nacheinander eingelesen
        types = ("*.MF4", "*.mf4")

        filedirs = self.filedir.split(",")
        for dir in filedirs:
            dir = dir.strip()
            # Laden aller mf4-Dateien im jeweiligen Ordner
            mf4_files = []
            for type in types:
                mf4_files.extend(glob.glob(os.path.join(dir, type)))
            # Einlesen aller mf4-Dateien im Ordner und Gruppierung nach Fahrten
            for x in mf4_files:
                # Trennung des Dateinamens am "#" und Sortierung der Fahrten anhand des vorderen Teils
                key = os.path.basename(x).split("#")[0]
                group = self.dict_files.get(key, [])
                group.append(x)
                group_unique = list(set(group))
                self.dict_files[key] = group_unique
        self.dict_files = dict(sorted(self.dict_files.items()))

    def __generate_fuse_set(self):
        mess_can = ["Mess_CAN", "MESS1_CAN"]
        for _, value in self.dict_files.items():
            # Für jede Datei im jeweiligen Messzeitraum
            for file in value:
                # Überprüfung, ob es sich um die Datei mit dem Mess-CAN handelt
                if any([x in file for x in mess_can]):
                    with MDF(file, raise_on_multiple_occurrences=False) as mf4_mess:
                        for fuses in self.fuse_bus_dict:
                            for fuse in fuses.split(","):
                                # Suchen der gewünschten Sicherungen im Mess-CAN
                                if self.fuse_prefix:
                                    self.set_fuses_names.update(
                                        mf4_mess.search(
                                            self.fuse_prefix + fuse + "*",
                                            case_insensitive=True,
                                            mode="wildcard",
                                        )
                                    )
                                self.set_fuses_names.update(
                                    mf4_mess.search(
                                        "I_" + fuse + "*",
                                        case_insensitive=True,
                                        mode="wildcard",
                                    )
                                )
                        # rename fuse prefix with 'I_' in self.set_fuses_names
                        if self.fuse_prefix:
                            self.set_fuses_names = {
                                x.replace(self.fuse_prefix, "I_")
                                for x in self.set_fuses_names
                            }

    ##########################################
    # Erstellen der Signalliste mit allen relevanten Signalen, sofern eine Textdatei mit Namen einer Sicherung (z.B. F215.txt) vorliegt
    ##########################################
    def __create_signallist(self, fuse, fi_signalnumber, fi_signalthreshold):
        """Erstellen der Signalliste mit allen relevanten Signalen, sofern eine Textdatei mit Namen einer Sicherung (z.B. F215.txt) vorliegt"""
        dict_signallist = {}
        if self.signaldir:
            # Laden aller Textdateien im angegebenen Ordner
            txt_files = glob.glob(os.path.join(self.signaldir, "*.txt"))
            for filename in txt_files:
                # Entfernen des Dateisuffix
                filenameShort = Path(filename).stem
                if filenameShort == fuse:
                    # Einlesen der Feature Importance- und Signalnamen-Spalte
                    listFI = pd.read_csv(filename, sep=" ", header=None, usecols=[0, 1])
                    listFI[0] = listFI[0].astype(float)

                    # Erstellen der Liste für die Signalauswahl
                    self.__calc_signallist(
                        fi_signalnumber,
                        fi_signalthreshold,
                        filename,
                        filenameShort,
                        listFI,
                        dict_signallist,
                    )
        return dict_signallist

    ##########################################
    # Select signals used for signallist
    ##########################################
    def __calc_signallist(
        self,
        fi_signalnumber,
        fi_signalthreshold,
        filename,
        filenameShort,
        listFI,
        dict_signallist,
    ):
        # Erstellen der Liste für die Signalauswahl
        if fi_signalnumber and fi_signalthreshold:
            # Threshold oder Signalanzal ist restriktiver
            if len(listFI.loc[listFI[0] > fi_signalthreshold].index) <= fi_signalnumber:
                listFI = listFI.loc[listFI[0] > fi_signalthreshold]
            else:
                listFI = listFI.head(fi_signalnumber)
            dict_signallist[filenameShort] = list(listFI[1])

        elif fi_signalnumber and not fi_signalthreshold:
            listFI = listFI.head(fi_signalnumber)
            dict_signallist[filenameShort] = list(listFI[1])

        elif not fi_signalnumber and fi_signalthreshold:
            listFI = listFI.loc[listFI[0] > fi_signalthreshold]
            dict_signallist[filenameShort] = list(listFI[1])
        else:
            logger.info(
                f"Please specify feature importance signalnumber or signalthreshold! All signals in {filename} will be used!"
            )
            dict_signallist[filenameShort] = list(listFI[1])

    ##########################################
    # Erstellen einer Liste mit Signalen, welche nicht eingelesen werden sollen
    ##########################################
    def __create_blacklist(self):
        """Erstellen einer Liste mit Signalen, welche nicht eingelesen werden sollen"""
        blacklist = []
        if self.blacklist:
            if os.path.isfile(self.blacklist):
                with open(self.blacklist, "r") as filestream:
                    # Einlesen aller Zeilen der Blacklist
                    for line in filestream:
                        line = line.strip()
                        blacklist.append(line)
        return blacklist

    ##########################################
    # Einlesen aller mf4-Dateien und zusammenführen der Busse mit dem Mess-CAN
    ##########################################
    def __load_files(
        self,
        fuse,
        raster,
        dict_signallist,
        list_blacklist,
        fuse_bus_dict,
        feature_list_model,
        target_list_model,
        use_outer_join: bool,
        feature_engineering,
        disable_bus_check: bool,
        filter_living_state: bool,
        file_analysis=False,
    ) -> pd.DataFrame | None:
        """Einlesen aller mf4-Dateien und zusammenführen der Busse mit dem Mess-CAN"""
        dataframes = []
        datafiles = []
        column_superset = set()
        mess_can = ["Mess_CAN", "MESS1_CAN"]
        is_ethernet = False

        fuse, list_fuses, busses = self.__extract_fuse_and_busses(fuse, fuse_bus_dict)

        # Für jeden Messzeitraum
        for key, value in self.dict_files.items():
            mf4_collection = []
            # Für jede Datei im jeweiligen Messzeitraum
            for file in value:
                logger.info(f"reading {file}")
                if self.modellib and disable_bus_check:
                    self.__read_bus_files(
                        file,
                        mf4_collection,
                        fuse,
                        dict_signallist,
                        list_blacklist,
                    )
                    break
                # Überprüfung, ob bereits alle benötigten MF4-Dateien gefunden wurden
                if len(mf4_collection) < (len(busses) + 1):
                    # Überprüfung, ob es sich um die Datei mit dem Mess-CAN handelt
                    if not (self.modellib or file_analysis):
                        if any([x in file for x in mess_can]):
                            list_fuse_names = self.__read_meas_files(
                                file, list_fuses, mf4_collection, fuse
                            )
                            if list_fuse_names is None:
                                return None
                            continue

                    # Sofern die Datei nicht zum Messcan passt, werden die restlichen Busse verglichen
                    for bus in busses:
                        # Überprüfung, ob Busname aus fuse_bus_dict im Dateinamen der MF4 enthalten ist
                        if bus in file:
                            # check if file contains ethernet logs
                            if "ETH" in file:
                                is_ethernet = True
                            self.__read_bus_files(
                                file,
                                mf4_collection,
                                fuse,
                                dict_signallist,
                                list_blacklist,
                            )
                else:
                    break
            # Überprüfung, ob für jeden Bus eine MF4-Datei sowie der MessCAN gefunden wurden
            if len(mf4_collection) > 1 or self.modellib or self.target_signal:
                logger.info(
                    f"Found {len(mf4_collection)} (of {len(busses)+1}) mf4s for {key} and fuse {fuse}"
                )
                if feature_engineering is not None:
                    # Kombinieren aller eingelesenen MF4-Dateien
                    with MDF.stack(mf4_collection) as mf4_stacked:
                        if len(busses) > 1:
                            # Einlesen aller verfügbaren Signale
                            channels = list(mf4_stacked.channels_db)
                            # Generierung eines Dataframes aus den gefilterten Signalen
                            df_mf4_stacked = mf4_stacked.to_dataframe(
                                channels=channels,
                                raster=raster,
                                time_from_zero=True,
                                reduce_memory_usage=True,
                                ignore_value2text_conversions=False,
                            )
                        else:
                            df_mf4_stacked = mf4_stacked.to_dataframe(
                                raster=raster,
                                time_from_zero=True,
                                reduce_memory_usage=True,
                                ignore_value2text_conversions=False,
                            )
                else:
                    # Kombinieren aller eingelesenen MF4-Dateien
                    with MDF.stack(mf4_collection) as mf4_stacked:
                        if len(busses) > 1:
                            # Einlesen aller verfügbaren Signale
                            channels = list(mf4_stacked.channels_db)
                            # Generierung eines Dataframes aus den gefilterten Signalen
                            df_mf4_stacked = mf4_stacked.to_dataframe(
                                channels=channels,
                                raster=raster,
                                time_from_zero=True,
                                reduce_memory_usage=True,
                                ignore_value2text_conversions=True,
                            )
                        else:
                            df_mf4_stacked = mf4_stacked.to_dataframe(
                                raster=raster,
                                time_from_zero=True,
                                reduce_memory_usage=True,
                                ignore_value2text_conversions=True,
                            )
                    # Ersetzung aller "nan" mit 0
                    df_mf4_stacked = df_mf4_stacked.fillna(0)

                # # only use data while "ISw_Stat_ST3" is "ACC", "IGN_ON" or "START"
                if filter_living_state:
                    if "ISw_Stat_ST3" in df_mf4_stacked.columns:
                        df_mf4_stacked = df_mf4_stacked[
                            df_mf4_stacked["ISw_Stat_ST3"].isin([2, 4, 5])
                        ]
                        logger.info("Only using data with active living state")

                # Rename fuse prefix with 'I_'
                if self.fuse_prefix:
                    df_mf4_stacked.rename(
                        columns=lambda x: x.replace(self.fuse_prefix, "I_"),
                        inplace=True,
                    )

                # Rename target signal starting with 'I_'
                if self.target_signal:
                    try:
                        df_mf4_stacked.rename(
                            columns={self.target_signal: "I_" + self.target_signal},
                            inplace=True,
                        )
                    except KeyError:
                        logger.warn("Target signal was not found")
                # check if a item in list_fuse_names starts with "A"
                if not (self.modellib or file_analysis or self.target_signal):
                    if any(item.startswith("A") for item in list_fuse_names):
                        # Add "I_" to all columns in df_mf4_stacked starting with "A"
                        df_mf4_stacked.rename(
                            columns=lambda x: "I_" + x if x.startswith("A") else x,
                            inplace=True,
                        )

                # Falls ein Modell aus einer .joblib Datei eingelesen wird, wird auf die im Modell vorhandenen und antrainierten Signale gefiltert
                if feature_list_model:
                    df_mf4_stacked = df_mf4_stacked[
                        df_mf4_stacked.columns.intersection(
                            feature_list_model + target_list_model
                        )
                    ]
                    logger.info(
                        f"Total number of imported columns: {len(df_mf4_stacked.columns)}"
                    )

                # Anhängen einer Spalte mit dem Dateinamen an den Dataframe
                df_mf4_stacked["file"] = key

                # Update superset of columns
                column_superset = column_superset.union(set(df_mf4_stacked.columns))

                # Liste mit allen Dataframes je Sicherung
                dataframes.append(df_mf4_stacked)
                # alternativ for append: pd.concat(axis=1)
                datafiles.append(key)
                logger.info(f"Total number of columns: {len(df_mf4_stacked.columns)}")
            else:
                logger.error(
                    f"No matching mf4-file found for timestamp {key} fuse {fuse}, missing files!"
                )
                continue
        if not (self.modellib or file_analysis):
            if len(datafiles) < 2:
                logger.error("More training data is required for model generation.")
                return None

        if feature_engineering is not None:
            # transform bytecode to category type
            for df in dataframes:
                # df[non_numeric_cols] = (df[non_numeric_cols].stack().str.decode("utf-8").unstack())
                non_numeric_cols = [
                    col
                    for col in df
                    if not pd.api.types.is_numeric_dtype(df[col]) and not col == "file"
                ]
                df[non_numeric_cols] = (
                    df[non_numeric_cols]
                    .apply(lambda x: x.str.decode("utf-8"))
                    .astype("category")
                    .apply(lambda x: x.cat.add_categories(["sna", "nan"]))
                )
            df_result = pd.concat(dataframes, join="outer")
            # remove columns containing only a single value
            drop_col = [
                col
                for col in df_result.columns
                if len(df_result[col].unique()) <= 1
                and col != "file"
                and not col.startswith("I_")
            ]
            if len(drop_col) > 0:
                df_result = df_result.drop(drop_col, axis=1)
            # Alphabetisches Sortieren der Spaltennamen
            # df_result = df_result.reindex(sorted(df_result.columns), axis=1)
            return df_result
        else:
            if disable_bus_check:
                return dataframes

            # Generierung eines Dataframes mit allen Fahrten je Sicherung
            df_result = pd.concat(
                dataframes, join="outer" if use_outer_join else "inner"
            )

            logger.info(
                f"Total number of files for fuse {fuse} and timestamp {key}: {len(dataframes)}"
            )
            logger.info(f"Total number of identical columns: {len(df_result.columns)}")

            if not use_outer_join:
                logger.info(
                    f"Unused columns: {column_superset.difference(set(df_result.columns))}"
                )

            # Fill NaN values with zeros
            df_result.fillna(value=0, inplace=True)

            # Remove ethernet specific objects from dataframe:
            if is_ethernet:
                file_column = df_result["file"]
                df_result = df_result.select_dtypes(exclude=["object"])
                df_result["file"] = file_column

            # Alphabetisches Sortieren der Spaltennamen
            df_result = df_result.reindex(sorted(df_result.columns), axis=1)
            return df_result

    ##########################################
    # Generate fuse and busses list
    ##########################################
    def __extract_fuse_and_busses(self, fuse, fuse_bus_dict):
        # Überprüfung, ob im fuse-Parameter mehrere Sicherungen in einer Liste kommasepariert übergeben werden
        if isinstance(fuse, list):
            busses = []
            fuse = fuse[0].strip()
            list_fuses = fuse.split(",")
            # check if multiple fuses are given
            if len(list_fuses) > 1:
                if fuse in fuse_bus_dict:
                    busses = fuse_bus_dict.get(fuse)
                else:
                    for f_idx in list_fuses:
                        if fuse_bus_dict.get(f_idx):
                            busses.append(fuse_bus_dict.get(f_idx))
                        else:
                            for key in fuse_bus_dict:
                                if f_idx in key:
                                    busses.append(fuse_bus_dict[key])
                    result = sum(busses, [])
                    seen = set()
                    busses = [x for x in result if x not in seen and not seen.add(x)]
            else:
                fuse = list_fuses[0]
                # Überprüfung, ob die Sicherung bereits in im fuse_bus_dict enthalten ist
                if fuse_bus_dict.get(fuse):
                    busses = fuse_bus_dict.get(fuse)
                else:
                    for key in fuse_bus_dict:
                        if fuse in key:
                            busses = fuse_bus_dict[key]
        else:
            fuse = fuse.strip()
            # splitting fuses if there are multiple target values
            list_fuses = fuse.split(",")
            # get corresponding busses to fuse from fuse_bus_dict
            busses = fuse_bus_dict.get(fuse)
        print(f"FuseList: {list_fuses}")
        print(f"Busses: {busses}")

        return fuse, list_fuses, busses

    ##########################################
    # Import all mf4 files with measurement signals
    ##########################################
    def __read_meas_files(self, file, list_fuses, mf4_collection, fuse) -> list | None:
        # Einlesen der MF4-Datei
        with MDF(file, raise_on_multiple_occurrences=False) as mf4_mess:
            # Überprüfung, ob es mehrere Ziel-Sicherungen gibt
            if len(list_fuses) > 1:
                list_fusesNames = []
                for fuseX in list_fuses:
                    # Suchen der gewünschten Sicherungen im Mess-CAN
                    list_fusesNames.extend(
                        mf4_mess.search(
                            "I_" + fuseX + "*",
                            case_insensitive=True,
                            mode="wildcard",
                        )
                    )
                    list_fusesNames.extend(
                        mf4_mess.search(
                            fuse + "_" + "*",
                            case_insensitive=False,
                            mode="wildcard",
                        )
                    )
                    if self.fuse_prefix:
                        list_fusesNames.extend(
                            mf4_mess.search(
                                self.fuse_prefix + fuseX + "*",
                                case_insensitive=True,
                                mode="wildcard",
                            )
                        )
                if len(list_fusesNames) == 0:
                    logger.warn(f"{fuse} was not found in measurement file!")
                    return None
                elif len(list_fusesNames) > 1:
                    list_fusesNames = list(set(list_fusesNames))
                mf4_mess_filtered = mf4_mess.filter(list_fusesNames)
            else:
                list_fusesNames = []
                # Suchen der gewünschten Sicherungen im Mess-CAN
                list_fusesNames.extend(
                    mf4_mess.search(
                        "I_" + fuse + "*",
                        case_insensitive=True,
                        mode="wildcard",
                    )
                )
                list_fusesNames.extend(
                    mf4_mess.search(
                        fuse + "_" + "*",
                        case_insensitive=False,
                        mode="wildcard",
                    )
                )
                if self.fuse_prefix:
                    list_fusesNames.extend(
                        mf4_mess.search(
                            self.fuse_prefix + fuse + "*",
                            case_insensitive=True,
                            mode="wildcard",
                        )
                    )
                if len(list_fusesNames) == 0:
                    logger.warn(f"{fuse} was not found in measurement file!")
                    return None
                elif len(list_fusesNames) > 1:
                    list_fusesNames = list(set(list_fusesNames))
                mf4_mess_filtered = mf4_mess.filter(list_fusesNames)
            mf4_collection.append(mf4_mess_filtered)
            return list_fusesNames

    ##########################################
    # Import all mf4 files with bus signals
    ##########################################
    def __read_bus_files(
        self,
        file,
        mf4_collection,
        fuse=None,
        dict_signallist=None,
        list_blacklist=None,
    ) -> None:
        # Einlesen aller Signale und Entfernung von dev-Signalen
        with MDF(file, raise_on_multiple_occurrences=False) as mf4_bus:
            allSignals = mf4_bus.search("*", case_insensitive=True, mode="wildcard")
            reduced_signals = self._remove_dev_signals(allSignals)
            # Überprüfung, ob für die Sicherung der Signalraum in __create_blacklist eingeschränkt wurde
            if list_blacklist is not None:
                if len(list_blacklist) > 0:
                    strippedSignals = [
                        signal for signal in allSignals if signal not in list_blacklist
                    ]
                    reduced_signals = self._remove_dev_signals(strippedSignals)
            # Überprüfung, ob für die Sicherung der Signalraum in __create_signallist eingeschränkt wurde
            if dict_signallist is not None and fuse is not None:
                if fuse in dict_signallist:
                    overlapsignals = set(dict_signallist[fuse]).intersection(
                        mf4_bus.search("*", case_insensitive=True, mode="wildcard")
                    )
                    reduced_signals = self._remove_dev_signals(overlapsignals)
            mf4_collection.append(mf4_bus.filter(reduced_signals))

    ##########################################
    # Erstellen eines Zeitfensters
    ##########################################
    def make_windowed(self, drive_df: pd.DataFrame, windowsize):
        """
        This method creates a time series window of a fixed size.

        Args:
            drive_df (DataFrame): A pandas DataFrame.
            windowsize (int): An integer representing the size of the time series window.

        Returns:
            DataFrame: A pandas DataFrame with time series windows.
        """
        target_columns = list(filter(lambda c: c.startswith("I_"), drive_df.columns))
        feature_columns = list(
            filter(lambda c: not c.startswith("I_"), drive_df.columns)
        )
        time_column = "timestamps"

        # save file column
        key = drive_df[drive_df.columns[-1]].values
        # cut file column from feature column
        feature_columns = feature_columns[:-1]

        t = drive_df.index
        X = drive_df[feature_columns].values
        y = drive_df[target_columns].values
        tmp = []
        for i in range(X.shape[0] - windowsize):
            tmp.append(
                [t[i + windowsize - 1]]
                + X[i : i + windowsize].flatten().tolist()
                + y[i + windowsize - 1].tolist()
            )

        win_feature_columns = []
        for back in range(windowsize):
            for col in feature_columns:
                win_feature_columns.append(f"{col}-{windowsize-back:04d}")

        df = pd.DataFrame(
            np.array(tmp), columns=[time_column] + win_feature_columns + target_columns
        )
        df.set_index("timestamps", inplace=True)

        # add file column
        df["file"] = key[:-windowsize]

        return df

    ##########################################
    # Entfernen von ausgewählten Signalen, welche keinen Mehrwert bieten
    ##########################################
    def _remove_dev_signals(self, signal_list):
        return [
            x
            for x in signal_list
            if all(
                y.lower() not in x.lower()
                for y in [
                    "SQC",
                    "Tick",
                    "VSS",
                    "AuthInfo",
                    "Freshness",
                    "ODO",
                    "CRC",
                    "Meas",
                    "DateTm",
                    "TmStmp",
                ]
            )
        ]

    def import_env_signals(self, list_files):
        signal_list = {
            "F999": [
                "AirTemp_Outsd_ST3",
                "VehSpd_Disp_ST3",
                "PN14_SupBat_Volt_ST3",
                "IHC_Brt_Outsd_ST3",
                "DAS_CuA_NumOfLaneDrvDir_ST3",
                "IHC_MotorWay_Dtct_ST3",
                "IHC_City_Dtct_ST3",
                "TGC_D_SeatBelt_Stat_ST3",
                "TGC_P_SeatBelt_Stat_ST3",
                "TGC_RL_SeatBelt_Stat_ST3",
                "TGC_RM_SeatBelt_Stat_ST3",
                "TGC_RR_SeatBelt_Stat_ST3",
                "Wpr_Stat_ST3",
                "AirTemp_Insd_ST3",
                "VehSpd_X_ST3",
                "SwIll_NightDay_ST3",
            ]
        }
        fuse_bus_list = {
            "F999": ["BODY1_CAN", "HEADUNIT1_CAN", "HEADUNIT2_CAN_2", "PERIPHERY_CAN"]
        }

        dict_files_recovery = self.dict_files
        self.dict_files = {key: dict_files_recovery[key] for key in list_files}
        df = self.__load_files(
            "F999", 0.1, signal_list, [], fuse_bus_list, None, None, False, None, True
        )
        self.dict_files = dict_files_recovery

        if df is None or df.empty:
            raise ValueError("Analyze data: import_env_signals: dataframe is empty")

        return df

    def import_file(
        self,
        file,
        raster,
        feature_engineering,
        feature_list_model,
        target_list_model,
    ):
        mf4_collection = []
        logger.info(f"reading {file}")
        self.__read_bus_files(
            file,
            mf4_collection,
        )

        df_mf4 = mf4_collection[0].to_dataframe(
            raster=raster,
            time_from_zero=True,
            reduce_memory_usage=True,
            ignore_value2text_conversions=(feature_engineering is None),
        )

        # Ersetzung aller "nan" mit 0
        df_mf4 = df_mf4.fillna(0)

        # Falls ein Modell aus einer .joblib Datei eingelesen wird, wird auf die im Modell vorhandenen und antrainierten Signale gefiltert
        if feature_list_model:
            df_mf4 = df_mf4[
                df_mf4.columns.intersection(feature_list_model + target_list_model)
            ]

        # Anhängen einer Spalte mit dem Dateinamen an den Dataframe
        df_mf4["file"] = file

        logger.info(f"Total number of columns: {len(df_mf4.columns)}")

        if feature_engineering is not None:
            # df[non_numeric_cols] = (df[non_numeric_cols].stack().str.decode("utf-8").unstack())
            non_numeric_cols = [
                col
                for col in df_mf4
                if not pd.api.types.is_numeric_dtype(df_mf4[col]) and not col == "file"
            ]
            df_mf4[non_numeric_cols] = (
                df_mf4[non_numeric_cols]
                .apply(lambda x: x.str.decode("utf-8"))
                .astype("category")
                .apply(lambda x: x.cat.add_categories(["sna", "nan"]))
            )
            # remove columns containing only a single value
            drop_col = [
                col
                for col in df_mf4.columns
                if len(df_mf4[col].unique()) <= 1
                and col != "file"
                and not col.startswith("I_")
            ]
            if len(drop_col) > 0:
                df_mf4 = df_mf4.drop(drop_col, axis=1)
            df_mf4 = df_mf4.reindex(sorted(df_mf4.columns), axis=1)
            return df_mf4
        else:
            df_mf4 = df_mf4.reindex(sorted(df_mf4.columns), axis=1)
            return df_mf4
